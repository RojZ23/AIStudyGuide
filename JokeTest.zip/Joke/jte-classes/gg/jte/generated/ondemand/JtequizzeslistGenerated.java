package gg.jte.generated.ondemand;
import com.example.joke.Quiz;
import java.time.format.DateTimeFormatter;
@SuppressWarnings("unchecked")
public final class JtequizzeslistGenerated {
	public static final String JTE_NAME = "quizzes-list.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,2,2,2,141,141,141,142,142,144,144,144,145,145,145,146,146,146,146,147,147,147,149,149,149,149,155,155,156,156,158,158,163,163,163,2,3,3,3,3};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String username, java.util.List<Quiz> quizzes) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\r\n    <title>All Quizzes - StudyGuide AI</title>\r\n    <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap\" />\r\n    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css\" />\r\n    <style>\r\n        body {\r\n            font-family: 'Inter', sans-serif;\r\n            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            color: #333;\r\n        }\r\n        .app-container {\r\n            background: rgba(255, 255, 255, 0.95);\r\n            min-height: 100vh;\r\n            backdrop-filter: blur(10px);\r\n            padding: 20px 40px;\r\n        }\r\n        header {\r\n            display: flex;\r\n            justify-content: space-between;\r\n            align-items: center;\r\n            margin-bottom: 24px;\r\n        }\r\n        .logo {\r\n            font-size: 28px;\r\n            font-weight: 800;\r\n            background: linear-gradient(135deg, #2563eb, #7c3aed);\r\n            -webkit-background-clip: text;\r\n            -webkit-text-fill-color: transparent;\r\n        }\r\n        nav a {\r\n            text-decoration: none;\r\n            color: #64748b;\r\n            font-weight: 500;\r\n            font-size: 15px;\r\n            padding: 10px 16px;\r\n            border-radius: 12px;\r\n            margin-right: 12px;\r\n        }\r\n        nav a.active, nav a:hover {\r\n            color: #2563eb;\r\n            background: rgba(37, 99, 235, 0.1);\r\n        }\r\n        .quizzes-container {\r\n            display: grid;\r\n            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));\r\n            gap: 24px;\r\n        }\r\n        .quiz-card {\r\n            background: white;\r\n            border-radius: 16px;\r\n            padding: 24px;\r\n            box-shadow: 0 4px 20px rgba(0,0,0,0.08);\r\n            border: 1px solid rgba(255,255,255,0.2);\r\n            transition: all 0.3s ease;\r\n        }\r\n        .quiz-card:hover {\r\n            transform: translateY(-5px);\r\n            box-shadow: 0 8px 30px rgba(0,0,0,0.12);\r\n        }\r\n        .quiz-title {\r\n            font-size: 20px;\r\n            font-weight: 600;\r\n            margin-bottom: 12px;\r\n            color: #1e293b;\r\n        }\r\n        .quiz-meta {\r\n            font-size: 14px;\r\n            color: #64748b;\r\n            margin-bottom: 12px;\r\n        }\r\n        .quiz-status {\r\n            display: inline-flex;\r\n            align-items: center;\r\n            gap: 6px;\r\n            padding: 6px 12px;\r\n            border-radius: 20px;\r\n            font-size: 12px;\r\n            font-weight: 600;\r\n            margin-bottom: 12px;\r\n        }\r\n        .status-in-progress {\r\n            background: rgba(245, 158, 11, 0.1);\r\n            color: #d97706;\r\n            border: 1px solid rgba(245, 158, 11, 0.2);\r\n        }\r\n        .status-completed {\r\n            background: rgba(16, 185, 129, 0.1);\r\n            color: #059669;\r\n            border: 1px solid rgba(16, 185, 129, 0.2);\r\n        }\r\n        .status-not-started {\r\n            background: rgba(107, 114, 128, 0.1);\r\n            color: #6b7280;\r\n            border: 1px solid rgba(107, 114, 128, 0.2);\r\n        }\r\n        .btn-take-quiz {\r\n            background: linear-gradient(135deg, #10b981, #059669);\r\n            color: white;\r\n            border: none;\r\n            padding: 10px 18px;\r\n            border-radius: 10px;\r\n            font-size: 14px;\r\n            font-weight: 500;\r\n            text-decoration: none;\r\n            cursor: pointer;\r\n            display: inline-flex;\r\n            align-items: center;\r\n            gap: 6px;\r\n            transition: all 0.3s ease;\r\n        }\r\n        .btn-take-quiz:hover {\r\n            transform: translateY(-2px);\r\n            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n<div class=\"app-container\">\r\n    <header>\r\n        <div class=\"logo\">StudyGuide AI</div>\r\n        <nav>\r\n            <a href=\"/dashboard\">Dashboard</a>\r\n            <a href=\"/guides/create\">Create Guide</a>\r\n            <a href=\"/guides/list\">Guides</a>\r\n            <a href=\"/guides/quizzes-list\" class=\"active\">Quizzes</a>\r\n            <a href=\"/logout\">Logout</a>\r\n        </nav>\r\n    </header>\r\n    <h1>All Your Quizzes</h1>\r\n    <div class=\"quizzes-container\">\r\n        ");
		if (quizzes != null && !quizzes.isEmpty()) {
			jteOutput.writeContent("\r\n            ");
			for (Quiz quiz : quizzes) {
				jteOutput.writeContent("\r\n                <div class=\"quiz-card\">\r\n                    <h3 class=\"quiz-title\">");
				jteOutput.setContext("h3", null);
				jteOutput.writeUserContent(quiz.title);
				jteOutput.writeContent("</h3>\r\n                    <p class=\"quiz-meta\"><i class=\"fas fa-book\"></i> From: ");
				jteOutput.setContext("p", null);
				jteOutput.writeUserContent(quiz.studyGuide.title);
				jteOutput.writeContent("</p>\r\n                    <span class=\"quiz-status status-");
				jteOutput.setContext("span", "class");
				jteOutput.writeUserContent(quiz.status.toLowerCase().replace('_', '-'));
				jteOutput.setContext("span", null);
				jteOutput.writeContent("\">\r\n                        <i class=\"fas fa-circle\"></i> ");
				jteOutput.setContext("span", null);
				jteOutput.writeUserContent(quiz.status.replace('_', ' '));
				jteOutput.writeContent("\r\n                    </span>\r\n                    <form action=\"/quizzes/");
				jteOutput.setContext("form", "action");
				jteOutput.writeUserContent(quiz.id);
				jteOutput.setContext("form", null);
				jteOutput.writeContent("\" method=\"get\" style=\"display:inline;\">\r\n                        <button type=\"submit\" class=\"btn-take-quiz\">\r\n                            <i class=\"fas fa-play\"></i> Take Quiz\r\n                        </button>\r\n                    </form>\r\n                </div>\r\n            ");
			}
			jteOutput.writeContent("\r\n        ");
		} else {
			jteOutput.writeContent("\r\n            <p>No quizzes found. Generate quizzes from your study guides!</p>\r\n        ");
		}
		jteOutput.writeContent("\r\n    </div>\r\n</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String username = (String)params.get("username");
		java.util.List<Quiz> quizzes = (java.util.List<Quiz>)params.get("quizzes");
		render(jteOutput, jteHtmlInterceptor, username, quizzes);
	}
}
