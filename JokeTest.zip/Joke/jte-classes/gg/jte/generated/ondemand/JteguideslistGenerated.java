package gg.jte.generated.ondemand;
import com.example.joke.StudyGuide;
import java.time.format.DateTimeFormatter;
@SuppressWarnings("unchecked")
public final class JteguideslistGenerated {
	public static final String JTE_NAME = "guides-list.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,2,2,2,14,14,117,117,118,118,120,120,120,122,122,122,124,124,124,126,126,126,126,130,130,131,131,133,133,138,138,138,2,3,3,3,3};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String username, java.util.List<StudyGuide> studyGuides) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\r\n    <title>All Study Guides - StudyGuide AI</title>\r\n    <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap\" />\r\n    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css\" />\r\n    <style>\r\n        ");
		jteOutput.writeContent("\r\n        body {\r\n            font-family: 'Inter', sans-serif;\r\n            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            color: #333;\r\n        }\r\n        .app-container {\r\n            background: rgba(255, 255, 255, 0.95);\r\n            min-height: 100vh;\r\n            backdrop-filter: blur(10px);\r\n            padding: 20px 40px;\r\n        }\r\n        header {\r\n            display: flex;\r\n            justify-content: space-between;\r\n            align-items: center;\r\n            margin-bottom: 24px;\r\n        }\r\n        .logo {\r\n            font-size: 28px;\r\n            font-weight: 800;\r\n            background: linear-gradient(135deg, #2563eb, #7c3aed);\r\n            -webkit-background-clip: text;\r\n            -webkit-text-fill-color: transparent;\r\n        }\r\n        nav a {\r\n            text-decoration: none;\r\n            color: #64748b;\r\n            font-weight: 500;\r\n            font-size: 15px;\r\n            padding: 10px 16px;\r\n            border-radius: 12px;\r\n            margin-right: 12px;\r\n        }\r\n        nav a.active, nav a:hover {\r\n            color: #2563eb;\r\n            background: rgba(37, 99, 235, 0.1);\r\n        }\r\n        .guides-container {\r\n            display: grid;\r\n            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));\r\n            gap: 24px;\r\n        }\r\n        .guide-card {\r\n            background: white;\r\n            border-radius: 16px;\r\n            padding: 24px;\r\n            box-shadow: 0 4px 20px rgba(0,0,0,0.08);\r\n            border: 1px solid rgba(255,255,255,0.2);\r\n            transition: all 0.3s ease;\r\n        }\r\n        .guide-card:hover {\r\n            transform: translateY(-5px);\r\n            box-shadow: 0 8px 30px rgba(0,0,0,0.12);\r\n        }\r\n        .guide-title {\r\n            font-size: 20px;\r\n            font-weight: 600;\r\n            margin-bottom: 12px;\r\n            color: #1e293b;\r\n        }\r\n        .guide-meta {\r\n            font-size: 14px;\r\n            color: #64748b;\r\n            margin-bottom: 20px;\r\n        }\r\n        .btn-view {\r\n            background: rgba(37, 99, 235, 0.1);\r\n            color: #2563eb;\r\n            border: 1px solid rgba(37, 99, 235, 0.2);\r\n            padding: 10px 18px;\r\n            border-radius: 10px;\r\n            font-size: 14px;\r\n            font-weight: 500;\r\n            cursor: pointer;\r\n            text-decoration: none;\r\n            display: inline-flex;\r\n            align-items: center;\r\n            gap: 6px;\r\n        }\r\n        .btn-view:hover {\r\n            background: #2563eb;\r\n            color: white;\r\n            transform: translateY(-2px);\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n<div class=\"app-container\">\r\n    <header>\r\n        <div class=\"logo\">StudyGuide AI</div>\r\n        <nav>\r\n            <a href=\"/dashboard\">Dashboard</a>\r\n            <a href=\"/guides/create\">Create Guide</a>\r\n            <a href=\"/guides/list\" class=\"active\">Guides</a>\r\n            <a href=\"/guides/quizzes-list\">Quizzes</a>\r\n            <a href=\"/logout\">Logout</a>\r\n        </nav>\r\n    </header>\r\n    <h1>All Your Study Guides</h1>\r\n    <div class=\"guides-container\">\r\n        ");
		if (studyGuides != null && !studyGuides.isEmpty()) {
			jteOutput.writeContent("\r\n            ");
			for (StudyGuide guide : studyGuides) {
				jteOutput.writeContent("\r\n                <div class=\"guide-card\">\r\n                    <h3 class=\"guide-title\">");
				jteOutput.setContext("h3", null);
				jteOutput.writeUserContent(guide.title);
				jteOutput.writeContent("</h3>\r\n                    <p class=\"guide-meta\">\r\n                        <i class=\"fas fa-calendar\"></i> ");
				jteOutput.setContext("p", null);
				jteOutput.writeUserContent(guide.createdAt.format(DateTimeFormatter.ofPattern("MMM d, yyyy")));
				jteOutput.writeContent("\r\n                        &nbsp;&nbsp;•&nbsp;&nbsp;\r\n                        <i class=\"fas fa-tag\"></i> ");
				jteOutput.setContext("p", null);
				jteOutput.writeUserContent(guide.subject != null ? guide.subject : "General");
				jteOutput.writeContent("\r\n                    </p>\r\n                    <a href=\"/guides/");
				jteOutput.setContext("a", "href");
				jteOutput.writeUserContent(guide.id);
				jteOutput.setContext("a", null);
				jteOutput.writeContent("\" class=\"btn-view\">\r\n                        <i class=\"fas fa-eye\"></i> View / Edit\r\n                    </a>\r\n                </div>\r\n            ");
			}
			jteOutput.writeContent("\r\n        ");
		} else {
			jteOutput.writeContent("\r\n            <p>You have no study guides yet. <a href=\"/guides/create\">Create your first guide here</a>.</p>\r\n        ");
		}
		jteOutput.writeContent("\r\n    </div>\r\n</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String username = (String)params.get("username");
		java.util.List<StudyGuide> studyGuides = (java.util.List<StudyGuide>)params.get("studyGuides");
		render(jteOutput, jteHtmlInterceptor, username, studyGuides);
	}
}
